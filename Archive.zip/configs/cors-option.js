const corsOptions = {
  origin: [
    "http://localhost:5173",
    "https://247shipslimited.com/",
    "https://admin.247shipslimited.com",
  ],
};

module.exports = { corsOptions };
